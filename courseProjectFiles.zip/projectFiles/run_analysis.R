# download and store all relevant files 
# comment out this section if data is already present in a directory called "projectData" ----------
print("Downloading course project data, this can take a while depending on the speed of your net connection ...")
downloadCommand= 'wget https://d396qusza40orc.cloudfront.net/getdata%2Fprojectfiles%2FUCI%20HAR%20Dataset.zip'
unzipCommand= 'unzip getdata%2Fprojectfiles%2FUCI\\ HAR\\ Dataset.zip'
renameCommand= 'mv UCI\\ HAR\\ Dataset/ projectData/'
system(downloadCommand)
system(unzipCommand)
system(renameCommand)

# import all functions and change dir -------
print("Starting the analysis...")
source('./utils.R')
setwd("./projectData/")

# run code ---------
fulldata= createFullData()
extract= keepRelevantColumns(fulldata, searchTerms= c('mean', 'std'))
tidy.data= computeAverages(fulldata, extract, 
                           level= c('activityName', 'subjectLabel'))
write.table(tidy.data, file= '../tidy_data.txt', sep= '\t', row.names= F)
print("Analysis complete, find the final file tidy_data.txt in your run directory")
