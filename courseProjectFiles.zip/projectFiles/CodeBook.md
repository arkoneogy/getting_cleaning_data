
Run details:
---------------------
The code run_analysis.R executes as follows:
1. Downloads the project data in the same directory where it is itself present, unzips it and 
changes the name of the extracted directory to be compatible to its internal uses.
2. Sources the "utils.R" file to obtain all relevant functions to run the analysis
3. Creates the train, test and full data sets, along with subject labels and activity names. 
It automatically attaches the column names in the data using the feature names provided. 
4. Creates a subset of columns depending on the column names desired, eg, mean and std columns
5. Computes a final rollup (mean) of the resulting dataset by ( subject x activity name ).
This dataset is written out as the final output "tidy_data.txt".

Variables in tidy_data.txt:
----------------------------
acvitiyName				Descriptive name of the activity being measured
subjectLabel			Numeric label to identify the subject performing the experiment

All other variables are the mean of the raw variables of the same name.
The rollup is performed by (activityName x subjectLabel)
The rollup applies to data points ACROSS test and train datasets.
