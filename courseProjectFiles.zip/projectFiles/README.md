
Course project submission for Getting and Cleaning Data, Dec 2014
=================================================================

Summary:
---------------------

This zip archive contains the submission files for the course project
in "Getting and Cleaning Data" Coursera MOOC for Dec 2014 session.

The archive contains the following files:
1. readme.md			-- this file
2. codebook.md 		-- a summary of the variables in the final output (tidy_data.txt)
3. run_analysis.R	-- top level script for running the analysis requested
4. utils.R				-- a bunch of functions defined to help the analysis

Running instructions:
---------------------

1. Unzip the zip file at any location you want. 
2. Start a terminal and cd to the directory where the zip file was extracted
3. Run the following command:

Rscript run_analysis.R

4. The code will produce prompts for what it is performing, no intermediate inputs are required
5. The final output (tidy_data.txt) will be produced in the same directory from where the code was run


Notes:
---------------------

1. It is NOT necessary for the project data to be present in the directory where you unzip the archive.
The code is designed to automatically download, unzip and move the data files to the directory it internally needs it to be in.

2. In the event you DO NOT want to separately download the files (since this step can be slow, depending on your net connection), 
please perform the following steps:
a) comment out the initial section of code (from line 3 to 9) in run_analysis.R
b) place the project data at the same directory level as run_analysis.R, and name the directory as "projectData"
c) Please DO NOT RENAME any of the internal directories (like "test", "train") or files (like "X_train.txt")
d) run the code using **RUNNING INSTRUCTIONS**

3. I have assumed that the "mean" variables refer to any variable that has "mean" in its name, eg, mean() as well as meanFreq(). 
This specification is present on line 18 of run_analysis.R in the "searchTerms" argument of the keepRelevantColumns function.
If you wish for only the "mean()" columns, simply change the searchTerms to c("mean()", "std"), etc.
