library(data.table)

# basic setup
trainDir= "./train/"
testDir= "./test/"

trainFile_x= "X_train.txt"
trainFile_y= "y_train.txt"
testFile_x= "X_test.txt"
testFile_y= "y_test.txt"

featuresFile= "features.txt"
activitiesFile= "activity_labels.txt"

trainSubjectsFile= "subject_train.txt"
testSubjectsFile= "subject_test.txt"



myReader= function(filename, colnames, isHeader= F) 
{
  dt= data.table(read.table(file= filename, header= isHeader))
  setnames(dt, names(dt), colnames)
  return (dt)
}



createFullData= function ()
{
  print("Obtaining feature names ...")
  features= as.character(myReader(filename = featuresFile, colnames= c('v1', 'v2'))$v2) 
  
  print("Getting train data ...")
  train.x= myReader (filename= paste0(trainDir, trainFile_x), colnames= features)
  train.y= myReader (filename= paste0(trainDir, trainFile_y), colnames= 'activityLabel')
  train.subjects= myReader(filename = paste0(trainDir, trainSubjectsFile), colnames= 'subjectLabel')
  train.full= cbind(train.subjects, train.x, train.y)
  
  print("Getting test data ...")
  test.x= myReader (filename= paste0(testDir, testFile_x), colnames= features)
  test.y= myReader (filename= paste0(testDir, testFile_y), colnames= 'activityLabel')  
  test.subjects= myReader(filename = paste0(testDir, testSubjectsFile), colnames= 'subjectLabel')
  test.full= cbind(test.subjects, test.x, test.y)
  
  print("Creating full data ...")
  train.full[, trainSet:= T]
  test.full[, trainSet:= F]
  fullData= rbind(train.full, test.full)
  
  print("Fetching activity names ...")
  activities= myReader(filename= activitiesFile, colnames = c('activityLabel', 'activityName'))
  setkeyv(fullData, 'activityLabel')
  setkeyv(activities, 'activityLabel')
  fullData= activities[fullData]
  
  print ("Done!")
  return (fullData)
}



keepRelevantColumns = function(data, searchTerms)
{
  data= copy(data)
  allnames= names(data)
  ret.data= data.table()
  
  for (term in searchTerms)
  {
    print(paste("Searching for all", term, "variables ..."))
    temp.names= allnames[ grepl(term, allnames, fixed=T)]
    
    if (nrow(ret.data)==0){
      ret.data= rbind(ret.data, data[, temp.names, with=F]) 
    } else {
      ret.data= cbind(ret.data, data[, temp.names, with=F])
    }
  }  
  return (ret.data)
}



computeAverages= function (fulldata, extract, level)
{
  data.ids= fulldata[, level, with=F]
  data= cbind(data.ids, extract)
  setkeyv(data.ids, NULL)  
  print(paste("Rolling up to create tidy data, expect", nrow(unique(data.ids)), 
              "rows in final dataset"))
  
  targs= names(extract)
  final= data[, lapply(.SD, mean), .SDcols= targs, by= level]
  setkeyv(final, level)
  
  return(final)
}
